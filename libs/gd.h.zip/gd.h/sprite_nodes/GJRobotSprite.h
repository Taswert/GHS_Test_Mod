#ifndef __GJROBOTSPRITE_H__
#define __GJROBOTSPRITE_H__

#include <gd.h>

namespace gd {

	class CCAnimatedSprite;

	class GJRobotSprite : public CCAnimatedSprite {

	};
}

#endif 