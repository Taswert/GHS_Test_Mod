#ifndef __GJSPIDERSPRITE_H__
#define __GJSPIDERSPRITE_H__

#include <gd.h>

namespace gd {

	class GJRobotSprite;

	class GJSpiderSprite : public GJRobotSprite {

	};
}

#endif 