#ifndef __SONGINFOOBJECT_H__
#define __SONGINFOOBJECT_H__

#include <gd.h>

namespace gd {
    class SongInfoObject : public cocos2d::CCNode {
        // todo
    };
}

#endif
