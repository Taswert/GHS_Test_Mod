#ifndef __GJSPECIALCOLORSELECT_H__
#define __GJSPECIALCOLORSELECT_H__

#include <gd.h>

namespace gd {

    class GJSpecialColorSelect : public gd::FLAlertLayer {
        // todo
    };

}

#endif
