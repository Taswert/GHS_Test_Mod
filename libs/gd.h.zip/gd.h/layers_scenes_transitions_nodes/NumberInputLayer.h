#ifndef NUMBERINPUTLAYER_H
#define NUMBERINPUTLAYER_H

#include <gd.h>

namespace gd {

    class NumberInputLayer : public FLAlertLayer {

    };

}

#endif
